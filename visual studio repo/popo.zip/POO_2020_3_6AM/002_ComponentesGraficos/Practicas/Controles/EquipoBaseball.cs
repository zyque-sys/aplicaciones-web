﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _002_ComponentesGraficos.Practicas.Controles
{
    public partial class EquipoBaseball : Form
    {
        static ClaseArregloDesordenado EquipoDeBeisbol = new ClaseArregloDesordenado(9);

        public EquipoBaseball()
        {
            CrearDataGrid();
            InitializeComponent();
        }
        #region Datagridview metodos
        private void CrearDataGrid()
        {
            dataGridView1.Columns.Add("Uniforme", "Uniforme");
            dataGridView1.Columns.Add("Nombre", "Nombre");
            dataGridView1.Columns.Add("Porcentaje de Bateo", "Porcentaje de Bateo");
        }
        private void MostrarDataGrid()
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();

            CrearDataGrid();
            ClaseDatos Jugador;
            for (int i = 0; i < EquipoDeBeisbol.Top - 1; i++)
            {
                Jugador = EquipoDeBeisbol.Consultar(i);
                dataGridView1.Rows.Add(Jugador.Uniforme, Jugador.Nombre, Jugador.Porcentaje);
            }
        }
        #endregion
        private void button1_Click(object sender, EventArgs e)
        {
            ClaseDatos Jugador = new ClaseDatos();

            Jugador.Uniforme = UInt16.Parse(textBox1.Text);
            Jugador.Nombre = textBox2.Text;
            Jugador.Porcentaje = double.Parse(textBox3.Text);

            if (EquipoDeBeisbol.Insertar(Jugador))
                MessageBox.Show("Se insertó el sig. jugador en el arreglo:\n\nNúm. Uniforme: " 
                    + Jugador.Uniforme.ToString() + 
                    "\nNombre: " + Jugador.Nombre + 
                    "\nPorcentaje de Bateo: " + Jugador.Porcentaje.ToString());
            else
                MessageBox.Show("No se pudo insertar el jugador :(");

            MostrarDataGrid();  

            textBox1.Clear();  
            textBox2.Clear();
            textBox3.Clear();
            textBox1.Focus();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (!EquipoDeBeisbol.EstaVacio())
            {
                string NumUniforme = textBox1.Text;

                if (NumUniforme == "") 
                {
                    DataGridViewRow RenglonSeleccionado = dataGridView1.CurrentRow;
                    if (RenglonSeleccionado == null) 
                        MessageBox.Show("Escriba el número de uniforme del jugador a eliminar o selecciónalo de la cuadricula", "[!]ERROR[!]:", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    else
                        NumUniforme = RenglonSeleccionado.Cells[0].Value.ToString();
                    
                }

                
                if (MessageBox.Show("¿ Está seguro que desea eliminar el jugador num." + NumUniforme + " ? ", "Presione un botón para continuar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (EquipoDeBeisbol.Eliminar(UInt16.Parse(NumUniforme)))
                        MessageBox.Show("Se eliminó el jugador");
                    else
                        MessageBox.Show("No se pudo eliminar el jugador num." + NumUniforme, "[!]ERROR[!]:", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                    MessageBox.Show("Eliminación cancelada", "[!]ERROR[!]:", MessageBoxButtons.OK, MessageBoxIcon.Error);

                MostrarDataGrid();
            }
            else
                MessageBox.Show("Arreglo vacío :(");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (EquipoDeBeisbol.Ordenar())  // Invoca el método Ordenar()
            {
                MostrarDataGrid();
            }
            else
                MessageBox.Show("Arreglo vacío :(");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (!EquipoDeBeisbol.EstaVacio())
            {
                ClaseDatos MejorBateador = EquipoDeBeisbol.Mayor();
                MessageBox.Show("Núm. Uniforme: " + MejorBateador.Uniforme + "\nNombre: " + MejorBateador.Nombre + "\nPorcentaje de Bateo: " + MejorBateador.Porcentaje, "El mejor bateador es el siguiente:\n", MessageBoxButtons.OK);
            }
            else
                MessageBox.Show("Arreglo vacío :(");
        }

    }
}
