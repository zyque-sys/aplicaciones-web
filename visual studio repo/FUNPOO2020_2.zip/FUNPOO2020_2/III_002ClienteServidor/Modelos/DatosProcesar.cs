﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace III_002ClienteServidor.Modelos
{
    static class DatosProcesar
    {
        public static int Suma(int a, int b)
        {
            return a + b;
        }
    }
}
