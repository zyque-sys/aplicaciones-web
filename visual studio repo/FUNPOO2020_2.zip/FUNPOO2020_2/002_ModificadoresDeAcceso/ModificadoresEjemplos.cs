﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _002_ModificadoresDeAcceso
{
    class ModificadoresEjemplos
    {
        public string nombre;
        private protected string direccion;
        protected internal int edad;
        internal string genero;
    }
}
