﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace III_001Monolitico
{
    class Program
    {
        static void Main(string[] args)
        {
            //almacenamiento
            int a;
            int[] A;
            //*clases identidad
            //*estructuras

            //presentacion
            Console.WriteLine("");
            Console.Write("");
            //lectura
            Console.ReadLine();
            Console.Read();
            Console.Read();
            //procesamiento

            //*operadores aritmeticos(+,-,*,/)
            //*operadores logicos(>,<,>=,<=,=,...)
            //*estructuras de control (if,switch)
            //*estructuras ciclicas (for,while,do-while)

        }
    }
}
