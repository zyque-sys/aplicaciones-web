﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace III_5CodigoDesdeUML
{
    //conjunto de clases
    public class Animal2
    {
        private int t;
        private int t2;

        public int T
        {
            get => default;
            set
            {
            }
        }

        public int T2
        {
            get => default;
            set
            {
            }
        }
    }

    public class Perro2 : Animal2
    {
    }

    public class Pato2 : Animal2
    {
    }
}
