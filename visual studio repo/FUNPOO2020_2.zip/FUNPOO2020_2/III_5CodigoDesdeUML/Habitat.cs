﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace III_5CodigoDesdeUML
{
    public enum Habitat
    {
        Aire = 1,
        Tierra = 2,
        Agua = 3,
        Anfibio = 4
    }
}
